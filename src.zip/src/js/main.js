var reportsWidget = {
    options: {
        containerSelector: '.reports',
        template: (
            '{{#.}}' +
                '<article class="reports_item flex flex3">' +
                    '<a href="{{cover}}" target="_blank">' +
                        '<img class="reports_cover" src="{{cover}}" alt="{{title}} Cover"/>' + // This was missing
                    '</a>' +
                    '<footer class="reports_docs">' +
                        '{{#documents}}' +
                            //'<h3 class="reports_title">' +
                                '<a href="{{url}}" target="_blank">{{title}} <span>({{file_size}})</span></a>' +
                            //'</h3>' +
                        '{{/documents}}' +
                    '</footer>' +
                '</article>' +
            '{{/.}}'
        )
    },

    init: function() {     // From dataset.js
        this.renderReports(reportData || []);
    },

    renderReports: function(reports) {
        var inst = this,
            options = inst.options;

        $(options.containerSelector).html(Mustache.render(options.template, reports));

    }
};

reportsWidget.init();
